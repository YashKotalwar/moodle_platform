<?php
define('API_KEY','2EsDG_KJQFGF8DCvCbZ9ww');
define('API_SECRET','XXfJBHy9JB0tgpazgXbMAVA50tfcGE98ctcw');
define('EMAIL_ID','yashkotalwar10@gmail.com');
?>